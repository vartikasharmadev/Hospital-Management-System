import { combineReducers } from "redux";
import authReducer from "./auth/reducer";
import dataReducer from "./Datas/reducer";

/**
 * Root Reducer
 * Combines all individual reducers into a single root reducer.
 * 
 * @property {Object} auth - Handles authentication state (login, register)
 * @property {Object} data - Handles application data (patients, doctors, etc.)
 */
export const rootReducer = combineReducers({
  auth: authReducer,
  data: dataReducer,
});
