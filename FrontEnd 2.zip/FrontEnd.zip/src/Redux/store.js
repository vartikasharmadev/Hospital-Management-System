import {
  legacy_createStore as createStore,
  applyMiddleware,
  compose,
} from "redux";
import thunk from "redux-thunk";
import { rootReducer } from "./index.js";

/**
 * Saves the current Redux state to LocalStorage.
 * This ensures state persistence across page reloads.
 * 
 * @param {Object} store - The Redux state object
 */
function saveToLocalStorage(store) {
  try {
    const serializedStore = JSON.stringify(store);
    window.localStorage.setItem("store", serializedStore);
  } catch (e) {
    console.log(e);
  }
}

/**
 * Loads the Redux state from LocalStorage.
 * 
 * @returns {Object|undefined} The parsed state object or undefined if not found
 */
function loadFromLocalStorage() {
  try {
    const serializedStore = window.localStorage.getItem("store");
    if (serializedStore === null) return undefined;
    return JSON.parse(serializedStore);
  } catch (e) {
    console.log(e);
    return undefined;
  }
}

// Enable Redux DevTools Extension if available
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

// Load initial state from local storage
const persistedState = loadFromLocalStorage();

/**
 * Redux Store Configuration
 * 
 * - Uses `rootReducer` to combine all application reducers.
 * - `persistedState` initializes the store with data from LocalStorage.
 * - Applies `thunk` middleware for handling asynchronous actions.
 * - Uses `composeEnhancers` to enable Redux DevTools.
 */
export const store = createStore(
  rootReducer,
  persistedState,
  composeEnhancers(applyMiddleware(thunk))
);

// Subscribe to store changes to save state to LocalStorage
store.subscribe(() => saveToLocalStorage(store.getState()));


