import * as types from "./types";
import axios from "axios";
import API_BASE_URL from "../../config/api";

/**
 * Logs in a nurse
 * @param {Object} data - Login credentials { nurseID, password }
 * @returns {Function} Thunk function
 */
export const NurseLogin = (data) => async (dispatch) => {
  try {
    dispatch({ type: types.LOGIN_NURSE_REQUEST });
    const res = await axios.post(
      `${API_BASE_URL}/nurses/login`,
      data
    );
    dispatch({
      type: types.LOGIN_NURSE_SUCCESS,
      payload: {
        message: res.data.message,
        user: res.data.user,
        token: res.data.token,
      },
    });
    return res.data;
  } catch (error) {
    dispatch({
      type: types.LOGIN_NURSE_ERROR,
      payload: {
        message: error,
      },
    });
  }
};

/**
 * Logs in a doctor
 * @param {Object} data - Login credentials { docID, password }
 * @returns {Function} Thunk function
 */
export const DoctorLogin = (data) => async (dispatch) => {
  try {
    dispatch({ type: types.LOGIN_DOCTOR_REQUEST });
    const res = await axios.post(
      `${API_BASE_URL}/doctors/login`,
      data
    );
    console.log(res.data);
    dispatch({
      type: types.LOGIN_DOCTOR_SUCCESS,
      payload: {
        message: res.data.message,
        user: res.data.user,
        token: res.data.token,
      },
    });
    return res.data;
  } catch (error) {
    dispatch({
      type: types.LOGIN_DOCTOR_ERROR,
      payload: {
        message: error,
      },
    });
  }
};

/**
 * Logs in an admin
 * @param {Object} data - Login credentials { adminID, password }
 * @returns {Function} Thunk function
 */
export const AdminLogin = (data) => async (dispatch) => {
  try {
    dispatch({ type: types.LOGIN_ADMIN_REQUEST });
    const res = await axios.post(
      `${API_BASE_URL}/admin/login`,
      data
    );
    console.log(res.data);
    dispatch({
      type: types.LOGIN_ADMIN_SUCCESS,
      payload: {
        message: res.data.message,
        user: res.data.user,
        token: res.data.token,
      },
    });
    return res.data;
  } catch (error) {
    dispatch({
      type: types.LOGIN_ADMIN_ERROR,
      payload: {
        message: error,
      },
    });
  }
};

/**
 * Registers a new doctor
 * @param {Object} data - Doctor details
 * @returns {Function} Thunk function
 */
export const DoctorRegister = (data) => async (dispatch) => {
  try {
    dispatch({ type: types.REGISTER_DOCTOR_REQUEST });
    const res = await axios.post(
      `${API_BASE_URL}/doctors/register`,
      data
    );
    return res.data;
  } catch (error) {
    dispatch({
      type: types.REGISTER_DOCTOR_ERROR,
      payload: {
        message: error,
      },
    });
  }
};

/**
 * Registers a new nurse
 * @param {Object} data - Nurse details
 * @returns {Function} Thunk function
 */
export const NurseRegister = (data) => async (dispatch) => {
  try {
    dispatch({ type: types.REGISTER_NURSE_REQUEST });
    const res = await axios.post(
      `${API_BASE_URL}/nurses/register`,
      data
    );
    return res.data;
  } catch (error) {
    dispatch({
      type: types.REGISTER_NURSE_ERROR,
      payload: {
        message: error,
      },
    });
  }
};

/**
 * Registers a new admin
 * @param {Object} data - Admin details
 * @returns {Function} Thunk function
 */
export const AdminRegister = (data) => async (dispatch) => {
  try {
    dispatch({ type: types.REGISTER_ADMIN_REQUEST });
    const res = await axios.post(
      `${API_BASE_URL}/admin/register`,
      data
    );
    return res.data;
  } catch (error) {
    dispatch({
      type: types.REGISTER_ADMIN_ERROR,
      payload: {
        message: error,
      },
    });
  }
};

/**
 * Registers a new ambulance
 * @param {Object} data - Ambulance details
 * @returns {Function} Thunk function
 */
export const AmbulanceRegister = (data) => async (dispatch) => {
  try {
    dispatch({ type: types.REGISTER_AMBULANCE_REQUEST });
    const res = await axios.post(
      `${API_BASE_URL}/ambulances/add`,
      data
    );
    console.log(res);
  } catch (error) {
    dispatch({
      type: types.REGISTER_AMBULANCE_ERROR,
      payload: {
        message: error,
      },
    });
  }
};

/**
 * Logs out the current user
 * @returns {Function} Thunk function
 */
export const authLogout = () => async (dispatch) => {
  try {
    dispatch({
      type: types.AUTH_LOGOUT,
    });
  } catch (error) {
    console.log(error);
  }
};

/**
 * Updates nurse details
 * @param {Object} data - Updated nurse data
 * @param {string} id - Nurse ID
 * @returns {Function} Thunk function
 */
export const UpdateNurse = (data, id) => async (dispatch) => {
  try {
    dispatch({ type: types.EDIT_NURSE_REQUEST });
    const res = await axios.patch(
      `${API_BASE_URL}/nurses/${id}`,
      data
    );
    console.log(res);
    dispatch({ type: types.EDIT_NURSE_SUCCESS, payload: res.data.user });
  } catch (error) {
    console.log(error);
  }
};

/**
 * Updates doctor details
 * @param {Object} data - Updated doctor data
 * @param {string} id - Doctor ID
 * @returns {Function} Thunk function
 */
export const UpdateDoctor = (data, id) => async (dispatch) => {
  try {
    dispatch({ type: types.EDIT_DOCTOR_REQUEST });
    const res = await axios.patch(
      `${API_BASE_URL}/doctors/${id}`,
      data
    );
    console.log(res);
    dispatch({ type: types.EDIT_DOCTOR_SUCCESS, payload: res.data.user });
  } catch (error) {
    console.log(error);
  }
};

/**
 * Sends password to user via email (Admin feature)
 * @param {Object} data - Email details
 * @returns {Function} Thunk function
 */
export const SendPassword = (data) => async (dispatch) => {
  try {
    dispatch({ type: types.EDIT_DOCTOR_REQUEST });
    const res = await axios.post(
      `${API_BASE_URL}/admin/password`,
      data
    );
    // console.log(res);
    return res.data;
  } catch (error) {
    console.log(error);
  }
};

/**
 * Handle forgot password request
 * @param {Object} data - User email and type
 * @returns {Function} Thunk function
 */
export const forgetPassword = (data) => async (dispatch) => {
  try {
    dispatch({ type: types.FORGET_PASSWORD_REQUEST });
    const res = await axios.post(
      `${API_BASE_URL}/admin/forgot`,
      data
    );
    // console.log(res);
    return res.data;
  } catch (error) {
    console.log(error);
  }
};
