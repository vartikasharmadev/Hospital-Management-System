import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { store } from "./Redux/store";

/**
 * Entry Point (index.js)
 * 
 * Boots up the React application.
 * - Wraps the app with `BrowserRouter` for routing.
 * - Wraps the app with `Provider` for Redux state management.
 * - Renders the root `App` component into the DOM.
 */
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <BrowserRouter>
    <Provider store={store}>
      <App />
    </Provider>
  </BrowserRouter>
);
