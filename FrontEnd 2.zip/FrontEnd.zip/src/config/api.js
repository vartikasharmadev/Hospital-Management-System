/**
 * API Configuration
 * 
 * Exports the base URL for the backend API.
 * Uses the React environment variable `REACT_APP_API_URL` if available,
 * otherwise defaults to `http://localhost:8080` for local development.
 * 
 * @constant {string} API_BASE_URL
 */
const API_BASE_URL = process.env.REACT_APP_API_URL || "http://localhost:8080";

export default API_BASE_URL;

