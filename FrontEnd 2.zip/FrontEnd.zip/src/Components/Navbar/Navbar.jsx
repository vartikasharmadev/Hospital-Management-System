import React from "react";

/**
 * Navbar Component
 * Renders the top navigation bar.
 * (Currently a placeholder)
 */
const Navbar = () => {
  return <div>Navbar</div>;
};

export default Navbar;
