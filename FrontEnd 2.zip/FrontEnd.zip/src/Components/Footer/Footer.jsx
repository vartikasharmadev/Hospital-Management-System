import React from 'react'
import './Footer.css'

const Footer = () => {
  return (
    <footer className="hms-footer">
      <p>&copy; 2024 Hospital Management System. Made with ❤️ by <strong>Vartika Sharma</strong></p>
    </footer>
  )
}

export default Footer