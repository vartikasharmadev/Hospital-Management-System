import "./App.css";
import AllRoutes from "./Routes/AllRoutes";

/**
 * App Component
 * 
 * Root component of the React application.
 * Renders the main routing component `AllRoutes`.
 */
function App() {
  return (
    <>
      <AllRoutes />
    </>
  );
}

export default App;
